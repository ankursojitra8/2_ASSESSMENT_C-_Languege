#include<iostream>
#include<ctime>
#include<string>
using namespace std;

class ATM
{
public:
    	ATM(int p, double b, string n, string a, string br, int ac)
        	: pin(p), balance(b), name(n), address(a), branch(br), accountNumber(ac) {}

    	void displayWelcome()
    	{
        	cout<<"\n\n\t\t\t *** Welcome to ATM  **** \n";
        	cout<<"\n\t\t ----------------------------------------\n";
	        time_t now=time(0); // Get a current time from the library #include<ctime>
    	    cout<<"\n\t\t Current date : "<<ctime(&now);
    	    cout<<"\n\t\t ----------------------------------------\n";
        	cout<<"\n\n\t |`-> Press 1 and Then Press Enter to Access your Account Via Pin Number    \n\n\t\t\t\t Or \n\n\t |`-> Press 0 and Press Enter to Get Help\n";
	    }

	    void accessAccount()
		{
        	int attempts=1;
        	int inputPin;
        	while(attempts<=2)
			{
            	cout<<"\n\n\t |`-> Enter your Acc PIN Access Number ! [ Only Two attempt is allowed ] : ";
            	cin>>inputPin;
            	if(inputPin==pin)
				{
                	displayMenu();
                	break;
            	}
				else
				{
                	cout<<"\n\t *** Error : You Had Made Your Attempt Which Failed !!  Sorry "<<attempts<<" Out of 2.\n";
				}
				attempts++;
        	}
        if(attempts>2)
        	{
        		cout<<"\n\n\n\t\t\t\t\t *** THANK YOU *** \n\n";
            	cout<<"\n\t *** Error : Incorrect PIN. Access denied !!  No More Attempt Allowed !!";
    		}
		}

    	void displayHelp()
    	{
        	cout<<"\n\t   	*** Error : You must have the correct PIN Number To Access This Account. See Your \n\t Bank Representative";
        	cout<<"For Assistance During Bank Opening Hours\n\t Thanks For, Your Choice Today !!  \n\n";
    	}

    	void displayMenu()
    	{
        	int choice;
        	cout<<"\n\n\t\t\t *** ATM Main Menu Screen *** ";
        	cout<<"\n\t Enter [1.] To Deposit Cash\n\t Enter [2.] To Withdraw Cash\n\t Enter [3.] To Balance Inquiry\n\t Enter [0.] To EXIT ATM \n\n\t |`-->> PLEASE ENTER  A SELECTION AND PRESS RETURN KEY : ";
        	cin>>choice;
        	switch(choice)
        	{
        	case 1:
            	deposit();
            	break;
        	case 2:
            	withdraw();
            	break;
        	case 3:
            	checkBalance();
            	break;
        	case 4:
            	cout<<"\n\n\t :) *** Thank you for using the ATM. *** (: \n";
            	break;
        	default:
            	cout<<"\n\t *** Error : Invalid choice.\n";
            	displayMenu();
            	break;
        	}
    	}

private:
    	int pin;
    	double balance;
    	string name, address, branch;
    	int accountNumber;

    	void deposit()
    	{
        	double amount;
        	cout<<"\n\n\t |`-> Enter the Amount to be Deposited Rs. ";
        	cin>>amount;
        	balance+=amount;
        	cout<<"\n\n\t -->> Your New available Balanced Amount is Rs. "<<balance<<"\n\n\t Thank You ! ";
    	}

    	void withdraw()
    	{
        	double amount;
        	cout<<"\n\n\t |`-> Enter Withdrawal Amount : ";
        	cin>>amount;
        	if (amount<=balance)
        	{
            	balance-=amount;
            	cout<<"\n\n\t -->> Your New available Balanced Amount is Rs. "<<balance<<"\n\n\t Thank You ! ";
        	}
        	else
            	cout<<"\n\t *** Error : Insufficient Available Balance In Your Account.\n";
    	}

    	void checkBalance()
    	{
        	cout<<"\n\n\t --->>> Your Balance is : "<<balance;
    	}
};

main()
{
    ATM atm(5678, 20000, "The Name Of Account Holders are Ankur Sojitra", "At. PO- Sajdiyali, Ta. Jam-Kandorana, Rajkot, Gujarat - 360 405", "BR SAJADIYALI", 937589504560);
    atm.displayWelcome();
    int choice;
    cin>>choice;

    switch(choice)
    {
    case 1: 
        	atm.accessAccount();
        	break;
    case 0: 
        	atm.displayHelp();
        	break;
    default:
        cout<<"\n\t *** Error : Invalid choice. Exiting program.\n";
        break;
    }
}

